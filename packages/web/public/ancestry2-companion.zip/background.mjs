import { runInAncestry } from './runner.mjs';
import { trustedSender, validMessage } from './policy.mjs';
let busy = false;
const activeJobs = new Map();
const execute = async (tabId, job) => {
  const frames = await chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', func: runInAncestry, args: [job] });
  if (!frames?.[0]?.result) throw new Error('The Ancestry tab did not return a result.');
  return frames[0].result;
};
chrome.action.onClicked.addListener(async tab => {
  try {
    if (!Number.isInteger(tab.id) || !/^https:\/\/www\.ancestry\.com\/family-tree\/person\/tree\/\d+\/person\/-?\d+(?:\/|$)/.test(tab.url || '')) throw new Error('Open the intended Ancestry person page, then click Ancestry2.');
    const result = await execute(tab.id, { op: 'context' });
    if (!result.ok) throw new Error(result.message);
    await chrome.storage.session.set({ connection: { tabId: tab.id, context: result.context } });
    await chrome.action.setBadgeText({ text: 'ON' });
    await chrome.action.setBadgeBackgroundColor({ color: '#27623c' });
    await chrome.action.setTitle({ title: `Ancestry2 connected: ${result.context.personName}. Return to RecordSeek and check connection.` });
  } catch (error) {
    await chrome.storage.session.remove('connection');
    await chrome.action.setBadgeText({ text: '!' });
    await chrome.action.setTitle({ title: error.message || 'Could not connect Ancestry2.' });
  }
});
async function save(message, connection) {
  const key = `job:${message.requestId}`;
  const old = (await chrome.storage.session.get(key))[key];
  if (old) return old;
  await chrome.storage.session.set({ [key]: { state: 'pending', requestId: message.requestId } });
  let result;
  try {
    result = await execute(connection.tabId, { op: 'save', expected: connection.context, target: message.target, source: message.source, citation: message.citation });
  } catch {
    result = { ok: false, phase: 'browser', mayHaveWritten: true, message: 'The Ancestry tab disconnected. Inspect the person before another save.', safeToRetryAutomatically: false };
  }
  const journal = { state: 'complete', requestId: message.requestId, result };
  await chrome.storage.session.set({ [key]: journal });
  return journal;
}
chrome.runtime.onMessage.addListener((message, sender, respond) => {
  if (!trustedSender(sender, chrome.runtime.id) || !validMessage(message)) return false;
  const handle = async () => {
    const connection = (await chrome.storage.session.get('connection')).connection;
    if (message.op === 'job') {
      const key = `job:${message.jobId}`;
      return (await chrome.storage.session.get(key))[key] || { state: 'missing' };
    }
    if (!connection) return { connected: false, message: 'Click the Ancestry2 companion on the intended Ancestry person page.' };
    if (message.op === 'status') {
      try {
        const live = await execute(connection.tabId, { op: 'context' });
        if (!live.ok || ['userId','treeId','personId'].some(key => live.context[key] !== connection.context[key])) throw new Error('Reconnect to the intended Ancestry person.');
        return { connected: true, context: live.context };
      } catch {
        await chrome.storage.session.remove('connection');
        return { connected: false, message: 'Reconnect the companion on the Ancestry person page.' };
      }
    }
    if (activeJobs.has(message.requestId)) return activeJobs.get(message.requestId);
    if (busy) throw new Error('An Ancestry2 save is already running.');
    busy = true;
    const pending = save(message, connection);
    activeJobs.set(message.requestId, pending);
    try { return await pending; } finally { busy = false; activeJobs.delete(message.requestId); }
  };
  handle().then(result => respond({ ok: true, result })).catch(error => respond({ ok: false, message: error.message || 'Ancestry2 companion failed.' }));
  return true;
});
