import { runInAncestry } from './runner.mjs';
import { trustedSender, validMessage } from './policy.mjs';
const VERSION = 2;
const ANCESTRY = 'https://www.ancestry.com/';
const SIGN_IN = 'https://www.ancestry.com/account/signin';
let busy = false;
const activeJobs = new Map();
const execute = async (tabId, job) => {
  const frames = await chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', func: runInAncestry, args: [job] });
  if (!frames?.[0]?.result) throw new Error('The Ancestry tab did not return a result.');
  return frames[0].result;
};
const loaded = tabId => new Promise((resolve, reject) => {
  const timer = setTimeout(() => { chrome.tabs.onUpdated.removeListener(watch); reject(new Error('Ancestry took too long to load. Try again.')); }, 25000);
  const watch = (id, info) => { if (id === tabId && info.status === 'complete') { clearTimeout(timer); chrome.tabs.onUpdated.removeListener(watch); resolve(); } };
  chrome.tabs.onUpdated.addListener(watch);
  chrome.tabs.get(tabId).then(tab => { if (tab.status === 'complete') watch(tabId, { status: 'complete' }); }).catch(() => {});
});
/** A loaded www.ancestry.com tab to run in: one the user has open, else a new background tab. */
async function ancestryTab() {
  const tabs = await chrome.tabs.query({ url: `${ANCESTRY}*` });
  const ready = tabs.find(t => t.status === 'complete' && !t.discarded) || tabs[0];
  if (ready) { if (ready.status !== 'complete' || ready.discarded) { await chrome.tabs.reload(ready.id); await loaded(ready.id); } return ready.id; }
  const tab = await chrome.tabs.create({ url: `${ANCESTRY}family-tree/trees`, active: false });
  await loaded(tab.id);
  return tab.id;
}
async function run(job) {
  const result = await execute(await ancestryTab(), job);
  if (!result.ok) throw new Error(result.message);
  return result;
}
/** Bring an Ancestry sign-in page to the front; RecordSeek keeps checking status until it succeeds. */
async function signIn() {
  const tabs = await chrome.tabs.query({ url: `${ANCESTRY}*` });
  const tab = tabs[0] ? await chrome.tabs.update(tabs[0].id, { active: true, url: SIGN_IN }) : await chrome.tabs.create({ url: SIGN_IN, active: true });
  if (Number.isInteger(tab.windowId)) await chrome.windows.update(tab.windowId, { focused: true }).catch(() => {});
  return { opened: true };
}
async function save(message) {
  const key = `job:${message.requestId}`;
  const old = (await chrome.storage.session.get(key))[key];
  if (old) return old;
  await chrome.storage.session.set({ [key]: { state: 'pending', requestId: message.requestId } });
  let result;
  try {
    result = await execute(await ancestryTab(), { op: 'save', expectedUserId: message.userId, target: message.target, source: message.source, citation: message.citation });
  } catch {
    result = { ok: false, phase: 'browser', mayHaveWritten: true, message: 'The Ancestry tab disconnected. Check the person on Ancestry before saving again.', safeToRetryAutomatically: false };
  }
  const journal = { state: 'complete', requestId: message.requestId, result };
  await chrome.storage.session.set({ [key]: journal });
  return journal;
}
chrome.runtime.onMessage.addListener((message, sender, respond) => {
  if (!trustedSender(sender, chrome.runtime.id) || !validMessage(message)) return false;
  const handle = async () => {
    if (message.op === 'job') {
      const key = `job:${message.jobId}`;
      return (await chrome.storage.session.get(key))[key] || { state: 'missing' };
    }
    if (message.op === 'status') {
      const { signedIn, userId, trees, recentTreeId } = await run({ op: 'status' });
      return { version: VERSION, signedIn, ...(signedIn ? { userId, trees, recentTreeId } : {}) };
    }
    if (message.op === 'signin') return signIn();
    if (message.op === 'search') return { people: (await run({ op: 'search', treeId: message.treeId, name: message.name })).people };
    if (activeJobs.has(message.requestId)) return activeJobs.get(message.requestId);
    if (busy) throw new Error('An Ancestry2 save is already running.');
    busy = true;
    const pending = save(message);
    activeJobs.set(message.requestId, pending);
    try { return await pending; } finally { busy = false; activeJobs.delete(message.requestId); }
  };
  handle().then(result => respond({ ok: true, result })).catch(error => respond({ ok: false, message: error.message || 'Ancestry2 companion failed.' }));
  return true;
});
