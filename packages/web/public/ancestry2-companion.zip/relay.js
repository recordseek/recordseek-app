(() => {
  const u = new URL(location.href);
  const trusted = ['http://127.0.0.1:9012','http://localhost:9012'].includes(u.origin) ||
    (u.origin === 'https://recordseek.com' && (u.pathname === '/share' || u.pathname.startsWith('/share/')));
  if (!trusted || window.top !== window) return;
  window.addEventListener('message', event => {
    const m = event.data;
    if (event.source !== window || event.origin !== location.origin || m?.channel !== 'recordseek.ancestry2' || m.version !== 1 || m.direction !== 'request' || !['status','save','job'].includes(m.op) || typeof m.requestId !== 'string') return;
    if (JSON.stringify(m).length > 200000) return;
    chrome.runtime.sendMessage(m, reply => {
      const error = chrome.runtime.lastError;
      window.postMessage({ channel: 'recordseek.ancestry2', version: 1, direction: 'response', requestId: m.requestId,
        ...(error ? { ok: false, message: 'Reload this page after enabling the Ancestry2 companion.' } : reply) }, location.origin);
    });
  });
})();
