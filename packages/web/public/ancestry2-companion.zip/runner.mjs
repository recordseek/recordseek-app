/** Serialized into the user-connected Ancestry tab; intentionally has no external dependencies. */
export async function runInAncestry(job) {
  let phase = 'context', sourceId, citationId;
  let attemptedWrite = false;
  try {
    const page = new URL(location.href);
    const match = page.pathname.match(/^\/family-tree\/person\/tree\/(\d+)\/person\/(-?\d+)(?:\/|$)/);
    if (page.origin !== 'https://www.ancestry.com' || !match) throw new Error('Open the intended person on www.ancestry.com and connect again.');
    let userId = globalThis.ancestry?.userId;
    if (!userId) {
      for (const link of document.querySelectorAll('a[href*="userId="]')) {
        const candidate = new URL(link.href, page.origin);
        if (candidate.origin === page.origin && candidate.searchParams.get('userId')) {
          userId = candidate.searchParams.get('userId'); break;
        }
      }
    }
    if (!userId || typeof userId !== 'string') throw new Error('Sign in to Ancestry, reload this person, and connect again.');
    const context = { userId, treeId: match[1], personId: match[2], personName: document.querySelector('h1')?.textContent?.trim() || 'Selected person' };
    if (job?.op === 'context') return { ok: true, context };
    if (job?.op !== 'save') throw new Error('Unsupported Ancestry2 operation.');
    if (!job.expected || ['userId', 'treeId', 'personId'].some(key => job.expected[key] !== context[key])) throw new Error('The connected account or person changed. Connect again before saving.');
    if (job.target && (job.target.treeId !== context.treeId || job.target.personId !== context.personId)) throw new Error('The selected target does not match the connected person.');
    const fields = ['title', 'auth', 'pub', 'publ', 'pubd', 'cn', 'note', 'refn', 'repositoryId'];
    const source = job.source, citation = job.citation;
    if (!source || typeof source.title !== 'string' || !source.title.trim() || source.title.length > 1000) throw new Error('Enter a source title of at most 1,000 characters.');
    if (!citation || typeof citation.detail !== 'string' || !citation.detail.trim() || citation.detail.length > 50000) throw new Error('Enter citation details of at most 50,000 characters.');
    const sourceBody = {};
    const escape = value => { const node = document.createElement('div'); node.textContent = value; return node.innerHTML; };
    for (const key of fields) {
      if (source[key] === undefined) continue;
      if (typeof source[key] !== 'string' || source[key].length > 50000) throw new Error('Invalid source field.');
      sourceBody[key] = escape(source[key]);
    }
    sourceBody.title = escape(source.title.trim());
    const citationUrl = citation.url ?? '';
    if (typeof citationUrl !== 'string' || citationUrl.length > 8000) throw new Error('Invalid citation URL.');
    if (citationUrl) {
      const url = new URL(citationUrl);
      if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password) throw new Error('Use an HTTP(S) citation URL without credentials.');
    }
    const base = `/family-tree/person/sourceedit/user/${encodeURIComponent(userId)}/tree/${context.treeId}`;
    const id = value => {
      const gid = typeof value?.gid === 'string' ? value.gid : value?.gid?.v;
      const parsed = typeof gid === 'string' ? gid.split(':')[0] : '';
      if (!parsed || !/^[A-Za-z0-9_-]+$/.test(parsed)) throw new Error('Ancestry did not return a usable identifier.');
      return parsed;
    };
    const call = async (path, method, body) => {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 20000);
      try {
        if (method === 'POST') attemptedWrite = true;
        const response = await fetch(path, { method, credentials: 'include', redirect: 'error', signal: controller.signal,
          headers: { Accept: 'application/json', 'Content-Type': 'application/json' },
          ...(body === undefined ? {} : { body: JSON.stringify(body) }) });
        if (!response.ok) throw new Error([401,403].includes(response.status) ? 'Ancestry denied the request. Check the signed-in account and reconnect.' : `Ancestry returned HTTP ${response.status}.`);
        return await response.json();
      } finally { clearTimeout(timeout); }
    };
    phase = 'source';
    sourceId = id(await call(`${base}/source`, 'POST', sourceBody));
    phase = 'citation';
    citationId = id(await call(`${base}/person/${context.personId}/citation`, 'POST', { title: escape(citation.detail), url: escape(citationUrl), sourceId }));
    phase = 'verification';
    const verifiedSource = id(await call(`${base}/source/${encodeURIComponent(sourceId)}`, 'GET'));
    if (verifiedSource !== sourceId) throw new Error('The returned source did not match the new source.');
    return { ok: true, verified: true, sourceId, citationId, treeId: context.treeId, personId: context.personId,
      personName: context.personName, personUrl: `${page.origin}/family-tree/person/tree/${context.treeId}/person/${context.personId}/facts` };
  } catch (error) {
    return { ok: false, phase, ...(sourceId ? { sourceId } : {}), ...(citationId ? { citationId } : {}),
      mayHaveWritten: attemptedWrite, message: error?.message || 'The browser could not confirm the result.', safeToRetryAutomatically: false };
  }
}
