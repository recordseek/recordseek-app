/** Serialized into a signed-in www.ancestry.com tab; intentionally has no external dependencies. */
export async function runInAncestry(job) {
  let phase = 'account', sourceId, citationId;
  let attemptedWrite = false;
  const call = async (path, method = 'GET', body) => {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 20000);
    try {
      if (method !== 'GET') attemptedWrite = true;
      const response = await fetch(path, { method, credentials: 'include', redirect: 'error', signal: controller.signal,
        headers: { Accept: 'application/json', 'Content-Type': 'application/json' },
        ...(body === undefined ? {} : { body: JSON.stringify(body) }) });
      if (!response.ok) throw new Error([401,403].includes(response.status) ? 'Ancestry denied the request. Sign in to Ancestry and try again.' : `Ancestry returned HTTP ${response.status}.`);
      return await response.json();
    } finally { clearTimeout(timeout); }
  };
  const digits = value => typeof value === 'string' && /^-?\d{1,20}$/.test(value);
  try {
    const page = new URL(location.href);
    if (page.origin !== 'https://www.ancestry.com') throw new Error('The companion can only run on www.ancestry.com.');
    if (job?.op === 'status') {
      // A signed-out session redirects these calls to the sign-in page, which fetch reports as an error.
      let list;
      try { list = await call('/api/treesui-list/trees?rights=own&page=1&limit=100'); }
      catch { return { ok: true, signedIn: false }; }
      const header = await call('/api/navheaderdata/v1/header/data/user').catch(() => ({}));
      const trees = (Array.isArray(list?.trees) ? list.trees : []).filter(t => digits(String(t.id)))
        .map(t => ({ id: String(t.id), name: String(t.name || 'Untitled tree') }));
      const userId = globalThis.ancestry?.userId || list?.trees?.[0]?.ownerUserId || '';
      const recent = header?.mostRecentlyViewedTreeId ? String(header.mostRecentlyViewedTreeId) : '';
      return { ok: true, signedIn: Boolean(userId), userId, trees, recentTreeId: trees.some(t => t.id === recent) ? recent : (trees[0]?.id || '') };
    }
    if (job?.op === 'search') {
      phase = 'search';
      if (!digits(job.treeId)) throw new Error('Choose a tree to search.');
      const name = typeof job.name === 'string' ? job.name.trim().slice(0, 200) : '';
      if (!name) throw new Error('Enter a name to search.');
      const people = await call(`/api/treesui-list/trees/${job.treeId}/persons?name=${encodeURIComponent(name)}&page=1&limit=50&fields=EVENTS,GENDERS,NAMES&isGetFullPersonObject=true`);
      const event = (p, type) => {
        const e = (p.Events || p.events || []).find(x => x.t === type);
        return e ? [e.d, e.p].filter(Boolean).join(', ') : '';
      };
      return { ok: true, people: (Array.isArray(people) ? people : []).filter(p => digits(String(p.pid))).map(p => ({
        personId: String(p.pid),
        name: [p.gname, p.sname].filter(Boolean).join(' ') || 'Unnamed person',
        gender: p.gender === 'm' ? 'male' : p.gender === 'f' ? 'female' : '',
        living: Boolean(p.isLiving), birth: event(p, 'Birth'), death: event(p, 'Death'),
      })) };
    }
    if (job?.op !== 'save') throw new Error('Unsupported Ancestry2 operation.');
    const userId = globalThis.ancestry?.userId;
    if (!userId || typeof userId !== 'string') throw new Error('Sign in to Ancestry, then try again.');
    if (job.expectedUserId !== userId) throw new Error('A different Ancestry account is signed in now. Go back and choose the person again.');
    const target = job.target;
    if (!target || !digits(target.treeId) || !digits(target.personId)) throw new Error('Choose the person to attach the source to.');
    phase = 'validation';
    const fields = ['title', 'auth', 'pub', 'publ', 'pubd', 'cn', 'note', 'refn', 'repositoryId'];
    const source = job.source, citation = job.citation;
    if (!source || typeof source.title !== 'string' || !source.title.trim() || source.title.length > 1000) throw new Error('Enter a source title of at most 1,000 characters.');
    if (!citation || typeof citation.detail !== 'string' || !citation.detail.trim() || citation.detail.length > 50000) throw new Error('Enter citation details of at most 50,000 characters.');
    const sourceBody = {};
    const escape = value => { const node = document.createElement('div'); node.textContent = value; return node.innerHTML; };
    for (const key of fields) {
      if (source[key] === undefined) continue;
      if (typeof source[key] !== 'string' || source[key].length > 50000) throw new Error('Invalid source field.');
      sourceBody[key] = escape(source[key]);
    }
    sourceBody.title = escape(source.title.trim());
    const citationUrl = citation.url ?? '';
    if (typeof citationUrl !== 'string' || citationUrl.length > 8000) throw new Error('Invalid citation URL.');
    if (citationUrl) {
      const url = new URL(citationUrl);
      if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password) throw new Error('Use an HTTP(S) citation URL without credentials.');
    }
    const base = `/family-tree/person/sourceedit/user/${encodeURIComponent(userId)}/tree/${target.treeId}`;
    const id = value => {
      const gid = typeof value?.gid === 'string' ? value.gid : value?.gid?.v;
      const parsed = typeof gid === 'string' ? gid.split(':')[0] : '';
      if (!parsed || !/^[A-Za-z0-9_-]+$/.test(parsed)) throw new Error('Ancestry did not return a usable identifier.');
      return parsed;
    };
    phase = 'source';
    sourceId = id(await call(`${base}/source`, 'POST', sourceBody));
    phase = 'citation';
    citationId = id(await call(`${base}/person/${target.personId}/citation`, 'POST', { title: escape(citation.detail), url: escape(citationUrl), sourceId }));
    phase = 'verification';
    const verifiedSource = id(await call(`${base}/source/${encodeURIComponent(sourceId)}`, 'GET'));
    if (verifiedSource !== sourceId) throw new Error('The returned source did not match the new source.');
    return { ok: true, verified: true, sourceId, citationId, treeId: target.treeId, personId: target.personId,
      personUrl: `${page.origin}/family-tree/person/tree/${target.treeId}/person/${target.personId}/facts` };
  } catch (error) {
    return { ok: false, phase, ...(sourceId ? { sourceId } : {}), ...(citationId ? { citationId } : {}),
      mayHaveWritten: attemptedWrite, message: error?.message || 'The browser could not confirm the result.', safeToRetryAutomatically: false };
  }
}
