export function trustedApp(url) {
  try {
    const u = new URL(url);
    return (['http://127.0.0.1:9012','http://localhost:9012'].includes(u.origin)) ||
      (u.origin === 'https://recordseek.com' && (u.pathname === '/share' || u.pathname.startsWith('/share/')));
  } catch { return false; }
}
export function trustedSender(sender, extensionId) {
  return sender?.id === extensionId && sender.frameId === 0 && Number.isInteger(sender.tab?.id) && trustedApp(sender.url);
}
export function validMessage(message) {
  return message?.channel === 'recordseek.ancestry2' && message.version === 1 &&
    typeof message.requestId === 'string' && /^[a-f0-9-]{36}$/i.test(message.requestId) &&
    ['status','save','job'].includes(message.op) && JSON.stringify(message).length <= 200000;
}
